
# Auteur : Olivier Poulin

## Titre : Examen final

## Description :
- Site web de voyage permettant de diriger les visiteurs vers la categorie de voyage qui les intéresse
- Creation d'une page des plus belles destinations à l'aide d'un plugin wordpress et du REST API

## Lien vers site hébergé :
- https://gftnth00.mywhc.ca/tim45/

