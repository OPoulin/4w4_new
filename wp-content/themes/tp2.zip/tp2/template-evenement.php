<?php
/**
 * Template name: Course
 *
 *
 */
?>