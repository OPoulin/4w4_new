
# Auteur : Olivier Poulin

## Titre : Examen Intra, Escapar

## Description :
- Site web de voyage permettant de diriger les visiteurs vers la categorie de voyage qui les intéresse
- Creation d'une page d'erreur adaptative lorsque la page cherchee n'existe pas

## Lien vers site hébergé :
- https://gftnth00.mywhc.ca/tim45/

