var btn = document.getElementById('bouton_retour');


btn.addEventListener('click', revenirFrontPage()) 



function revenirFrontPage() {
    console.log("HAHAHAHAHAAHAHAHAHAHAH")
    document.location.href = 'https://gftnth00.mywhc.ca/tim45/';
};