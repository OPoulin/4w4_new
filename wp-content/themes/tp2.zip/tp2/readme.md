
# Auteur : Olivier Poulin

## Titre : TP2 carroussel

## Description :
- Site web de voyage permettant de diriger les visiteurs vers la categorie de voyage qui les intéresse
- Creation d'un plugin de carrousel dans la page de Kyoto, Japon qui montre les images de la galerie une par une
- Ajout d'animations et du plugin de température sur le single.php

## Lien vers site hébergé :
- https://gftnth00.mywhc.ca/tim45/

